package bufmgr;

public class LRUK extends Replacer {

	/**
	 * Correlated reference period.
	 */
	private static final long CORR_REF_PER = 0;

	/**
	 * Parameter of the LRU-K. How many references do we consider ?
	 */
	private int K;

	/**
	 * private field
	 * An array to hold number of frames in the buffer pool
	 */
	private int frames[];

	/**
	 * Get frames.
	 *
	 * @return frames
	 */
	public int[] getFrames() { return frames; }

	/**
	 * private field
	 * number of frames used
	 */
	private int nframes;

	/**
	 * History matrix of the references of each pages.
	 * hist[frame][i] gives the time of the i_th reference of frame
	 */
	private long hist[][];

	/**
	 * Get the i_th reference of page
	 *
	 * @param page	
	 * @param i
	 * @return time of i_th reference of page
	 */
	public long HIST(int page, int i) { return hist[page][i]; }

	/**
	 * List of the most recent time of reference to frame
	 * last[frame] is the time in millisecond of the last reference
	 */
	private long last[];

	/**
	 * Get the time of the last reference of frame
	 *
	 * @param page	 
	 * @return time of last reference of frame
	 */
	public long last(int frame) { return last[frame]; }
	

	
	
	
	/**
	 * Class constructor
	 * Initializing frames[] pinter = null.
	 * We add K to know which LRU-K algorithm we are going to use. 
	 */
	public LRUK(BufMgr mgrArg, int K)
	{
		super(mgrArg);
		frames = null;
		this.K = K;
	}
	
	/**
	 * Calling super class the same method
	 * Initializing the frames[] with number of buffer allocated
	 * by buffer manager
	 * set number of frame used to zero
	 *
	 * @param	mgr	a BufMgr object
	 * @see	BufMgr
	 * @see	Replacer
	 */
	public void setBufferManager( BufMgr mgr )
	{
		super.setBufferManager(mgr);
		frames = new int [ mgr.getNumBuffers() ];
		nframes = 0;
		hist = new long [mgr.getNumBuffers()][K];
		last = new long [mgr.getNumBuffers()];
	}
	

	
	
	
	/**
	 * call super class the same method
	 * pin the page in the given frame number 
	 *
	 * @param	 frame	 the frame number to pin
	 * @exception  InvalidFrameNumberException
	 */
	public void pin(int frame) throws InvalidFrameNumberException
	{
		super.pin(frame);
		update(frame);
	}
	
	
	
	
	
	/**
	 * Finding a free frame in the buffer pool
	 * or choosing a page to replace using LRU policy
	 *
	 * @return 	return the frame number
     * @exception  BufferPoolExceededException if the buffer has no more room
	 */
	public int pick_victim() throws BufferPoolExceededException
	{
		long time = System.currentTimeMillis();
		int frame;
		int numBuffers = mgr.getNumBuffers();
		
		long minTime = time;
		int victim = -1; // TA in discord talked about returning -1 if there was an error.
		
		// Finding a free frame if the buffer is not full.
		if ( nframes < numBuffers ) {
			frame = nframes++;
			frames[frame] = frame;
			state_bit[frame].state = Pinned;
			(mgr.frameTable())[frame].pin();
			return frame;
		}
		
	    // If the buffer is full : find a replacement.
	    // Using LRU-K policy. Pick the frame with a maximum K-distance backward.
		// Because the search is reversed, we are in fact picking the minimum
		for ( int i = 0; i < numBuffers; ++i ) {
			frame = frames[i];
			if ( time-last[frame]>= CORR_REF_PER && hist[frame][K-1]<=minTime && state_bit[frame].state != Pinned ) {
				victim = frame;
				minTime = hist[victim][K-1];
			}
		}
		
		// We pin the frame
		if (victim >=0) {
			(mgr.frameTable())[victim].pin();
			state_bit[victim].state = Pinned;
			return victim;
		}
		
		// Throw BufferPoolExceededException if every frame are pinned. (victim = -1)
		throw new BufferPoolExceededException (null, "BUFMGR: BUFMGR_EXCEEDED.");
	}

	
	
	/**
	 * This update the frames and their histories after each pin.
	 * @param frame
	 */
	private void update(int frame)
	{	
		int 	index;
		long 	time = System.currentTimeMillis();
		boolean	exist = false; // If the page was in the buffer already


		for ( index=0; index < nframes; ++index )
			if ( frames[index] == frame ) {
				exist = true;
				break;
			}

		// Here if the Kth occurence of frame is correlated to the (K-1)th
		// Then only last is updated and not hist
		// If the page is indeed already in the buffer, we update its history
		if (exist) {
			if ( time-last[frame]>= CORR_REF_PER ) {
				// The reference is uncorelated, we have to update both hist and last
				long ref_Page = last[frame] - hist[frame][0];
				for (int i=1; i<K; i++) {
					hist[frame][i] = hist[frame][i-1] + ref_Page;
				}
				last[frame] = time;
				hist[frame][0] = time;
			} else {
				// The reference is correlated, we only have to update last
				last[frame] = time;
			}

		} 

	}	




	
	/**
	 * get the page replacement policy name
	 *
	 * @return	return the name of replacement policy used
	 */  
	public String name() { return "LRUK"; }

	/**
	 * print out the information of frame usage
	 */  
	public void info()
	{
		super.info();
		System.out.print( "LRU-k REPLACEMENT");

		for (int i = 0; i < nframes; i++) {
			if (i % 5 == 0)
				System.out.println( );
			System.out.print( "\t" + frames[i]);
		}
		System.out.println();
	} // End info()


}// End LRUK
