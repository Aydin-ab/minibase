module minibase {
}